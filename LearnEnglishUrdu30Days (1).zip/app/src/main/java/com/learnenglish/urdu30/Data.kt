package com.learnenglish.urdu30

import android.content.Context
import kotlin.random.Random

sealed class Block {
    data class Note(val text: String) : Block()
    data class Title(val text: String) : Block()
    data class Sent(val en: String, val ur: String, val tag: String = "") : Block()
}

class Day(
    val n: Int,
    val title: String,
    val week: String,
    val weekIntro: String,
    val blocks: List<Block>
) {
    val sents: List<Block.Sent> = blocks.filterIsInstance<Block.Sent>()
    val notes: List<String> = blocks.filterIsInstance<Block.Note>().map { it.text }
}

object Curriculum {
    var days: List<Day> = emptyList()
    var guide: List<Pair<String, String>> = emptyList()

    fun load(ctx: Context) {
        if (days.isNotEmpty()) return
        val g = mutableListOf<Pair<String, String>>()
        val ds = mutableListOf<Day>()
        var week = ""
        var intro = ""
        var n = 0
        var title = ""
        var blocks = mutableListOf<Block>()
        var curWeek = ""
        var curIntro = ""
        ctx.assets.open("curriculum.txt").bufferedReader(Charsets.UTF_8).use { r ->
            for (raw in r.readLines()) {
                val line = raw.trim()
                if (line.isEmpty()) continue
                val p = line.split("|")
                when (p[0]) {
                    "G" -> g.add(p[1] to p[2])
                    "WEEK" -> {
                        week = p[1]
                        intro = if (p.size > 2) p[2] else ""
                    }
                    "DAY" -> {
                        if (n > 0) ds.add(Day(n, title, curWeek, curIntro, blocks.toList()))
                        n = p[1].toInt()
                        title = p[2]
                        blocks = mutableListOf()
                        curWeek = week
                        curIntro = intro
                        week = ""
                        intro = ""
                    }
                    "NOTE" -> blocks.add(Block.Note(p[1]))
                    "CONV" -> blocks.add(Block.Title(p[1]))
                    "S" -> blocks.add(Block.Sent(p[1], p[2]))
                    "L" -> blocks.add(Block.Sent(p[2], p[3], p[1]))
                    "T" -> blocks.add(Block.Sent(p[2], p[3], p[1]))
                }
            }
        }
        if (n > 0) ds.add(Day(n, title, curWeek, curIntro, blocks.toList()))
        days = ds
        guide = g
    }

    /** Sentences used for revision flashcards: week 7/14/21 revise the previous six days too. */
    fun revisionSentences(day: Int): List<Block.Sent> {
        val d = days[day - 1]
        return if (day == 7 || day == 14 || day == 21) {
            days.subList(day - 7, day - 1).flatMap { it.sents } + d.sents
        } else d.sents
    }

    val totalSentences: Int get() = days.sumOf { it.sents.size }
}

enum class QT { MCQ, E2U, U2E, MISSING, ARRANGE, MATCH, TF }

data class Question(
    val type: QT,
    val prompt: String,
    val sub: String = "",
    val options: List<String> = emptyList(),
    val answer: String = "",
    val tokens: List<String> = emptyList(),
    val pairsEn: List<String> = emptyList(),
    val pairsUr: List<String> = emptyList(),
    val tfTrue: Boolean = true,
    val full: String = ""
)

object QuizGen {
    const val COUNT = 20

    private fun core(w: String): String = w.trim { !(it.isLetterOrDigit() || it == '\'') }

    fun build(day: Int): List<Question> {
        val d = Curriculum.days[day - 1]
        val rnd = Random(day * 7919)
        val own = d.sents.map { it.en to it.ur }.distinctBy { it.first }
        val extra: List<Pair<String, String>> =
            if (day == 7 || day == 14 || day == 21) {
                Curriculum.days.subList(day - 7, day - 1)
                    .flatMap { dd -> dd.sents.map { it.en to it.ur } }
                    .distinctBy { it.first }
                    .filter { p -> own.none { it.first == p.first } }
            } else emptyList()
        val items = own.shuffled(rnd) + extra.shuffled(rnd)
        val all = Curriculum.days.flatMap { dd -> dd.sents.map { it.en to it.ur } }.distinct()
        val vocab = all.flatMap { it.first.split(" ") }.map { core(it) }.filter { it.length >= 3 }.distinct()
        val out = mutableListOf<Question>()
        for (i in 0 until COUNT) {
            val (en, ur) = items[i % items.size]
            val enW = en.split(" ").filter { it.isNotEmpty() }
            val urW = ur.split(" ").filter { it.isNotEmpty() }
            var type = QT.values()[i % 7]
            if ((type == QT.ARRANGE && enW.size < 3) ||
                (type == QT.E2U && urW.size < 3) ||
                (type == QT.MISSING && enW.size < 2)
            ) type = QT.MCQ
            val others = all.filter { it.first != en && it.second != ur }.shuffled(rnd)
            val q: Question = when (type) {
                QT.MCQ -> {
                    val dis = others.map { it.second }.distinct().take(3)
                    Question(type = type, prompt = en, options = (dis + ur).shuffled(rnd), answer = ur)
                }
                QT.U2E -> {
                    val dis = others.map { it.first }.distinct().take(3)
                    Question(type = type, prompt = ur, options = (dis + en).shuffled(rnd), answer = en)
                }
                QT.E2U -> Question(type = type, prompt = en, answer = ur, tokens = urW.shuffled(rnd))
                QT.ARRANGE -> Question(type = type, prompt = ur, answer = en, tokens = enW.shuffled(rnd))
                QT.MISSING -> {
                    val idx = enW.indices.maxByOrNull { core(enW[it]).length } ?: 0
                    val c = core(enW[idx])
                    val blanked = enW.mapIndexed { j, w -> if (j == idx) w.replace(c, "____") else w }.joinToString(" ")
                    val dis = vocab.filter { it.lowercase() != c.lowercase() }.shuffled(rnd).take(3)
                    Question(type = type, prompt = blanked, sub = ur, options = (dis + c).shuffled(rnd), answer = c, full = en)
                }
                QT.MATCH -> {
                    val pairs = listOf(en to ur) + (items.shuffled(rnd) + others)
                        .filter { it.first != en && it.second != ur }
                        .distinctBy { it.first }
                        .distinctBy { it.second }
                        .take(3)
                    Question(
                        type = type,
                        prompt = "Match each English sentence with its Urdu meaning",
                        pairsEn = pairs.map { it.first },
                        pairsUr = pairs.map { it.second }
                    )
                }
                QT.TF -> {
                    val truth = rnd.nextBoolean()
                    val shown = if (truth) ur else others.first().second
                    Question(
                        type = type, prompt = en, sub = shown,
                        options = listOf("True", "False"),
                        answer = ur, tfTrue = truth
                    )
                }
            }
            out.add(q)
        }
        return out
    }
}
