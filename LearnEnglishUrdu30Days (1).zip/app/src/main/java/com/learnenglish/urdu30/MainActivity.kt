package com.learnenglish.urdu30

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { Root() } }
    }
}

private data class Tab(val route: String, val label: String, val emoji: String)

@Composable
fun Root() {
    val vm: AppVm = viewModel()
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(
        Tab("home", "Home", "🏠"),
        Tab("levels", "Levels", "📚"),
        Tab("wallet", "Wallet", "🪙"),
        Tab("progress", "Progress", "📊"),
        Tab("settings", "Settings", "⚙️")
    )
    Scaffold(
        bottomBar = {
            if (tabs.any { it.route == route }) {
                NavigationBar(containerColor = Color.White) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = {
                                vm.sfx(S.CLICK)
                                nav.navigate(t.route) {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Text(t.emoji, fontSize = 20.sp) },
                            label = { Text(t.label, fontSize = 11.sp) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "splash", modifier = Modifier.padding(pad)) {
            composable("splash") { SplashScreen(vm, nav) }
            composable("home") { HomeScreen(vm, nav) }
            composable("levels") { LevelsScreen(vm, nav) }
            composable("wallet") { WalletScreen(vm) }
            composable("progress") { ProgressScreen(vm, nav) }
            composable("settings") { SettingsScreen(vm, nav) }
            composable("guide") { GuideScreen(nav) }
            composable("final") { FinalScreen(vm, nav) }
            composable("results") { ResultsScreen(vm, nav) }
            composable("lesson/{d}", arguments = listOf(navArgument("d") { type = NavType.IntType })) {
                LessonScreen(vm, it.arguments?.getInt("d") ?: 1, nav)
            }
            composable("quiz/{d}", arguments = listOf(navArgument("d") { type = NavType.IntType })) {
                QuizScreen(vm, it.arguments?.getInt("d") ?: 1, nav)
            }
            composable("revision/{d}", arguments = listOf(navArgument("d") { type = NavType.IntType })) {
                RevisionScreen(vm, it.arguments?.getInt("d") ?: 1, nav)
            }
        }
    }
}
