@file:OptIn(ExperimentalLayoutApi::class)

package com.learnenglish.urdu30

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

data class SV(val idx: Int, val s: Block.Sent, val label: String)

fun buildCtx(day: Day): List<SV> {
    var title = ""
    var i = 0
    val out = mutableListOf<SV>()
    for (b in day.blocks) {
        when (b) {
            is Block.Title -> title = b.text
            is Block.Note -> {}
            is Block.Sent -> {
                val lab = listOf(title, if (b.tag.isEmpty()) "" else tagLabel(b.tag)).filter { it.isNotEmpty() }.joinToString(" • ")
                out.add(SV(i, b, lab))
                i++
            }
        }
    }
    return out
}

@Composable
fun LessonScreen(vm: AppVm, d: Int, nav: NavController) {
    if (d !in vm.unlocked) LockedView({ nav.popBackStack() }) else LessonContent(vm, d, nav)
}

@Composable
fun LessonContent(vm: AppVm, d: Int, nav: NavController) {
    val day = Curriculum.days[d - 1]
    val ctx = remember(d) { buildCtx(day) }
    var mode by remember { mutableStateOf(0) }
    var idx by remember { mutableStateOf(0) }
    var showUr by remember { mutableStateOf(true) }
    var notesOpen by remember { mutableStateOf(false) }
    var reward by remember { mutableStateOf(-1) }
    val learnedCount = vm.learnedCount(d)
    val allLearned = learnedCount == ctx.size
    val lessonDone = d in vm.lessonDone

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar("Day $d", { nav.popBackStack() })
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            if (day.week.isNotEmpty()) UrduText(day.week, Modifier.fillMaxWidth(), 14, color = Purple, bold = true)
            if (day.weekIntro.isNotEmpty()) UrduText(day.weekIntro, Modifier.fillMaxWidth(), 15)
            UrduText(day.title, Modifier.fillMaxWidth(), 20, bold = true)
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = learnedCount / ctx.size.toFloat(),
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)),
                color = Green, trackColor = Color(0xFFDCFCE7)
            )
            Text("Learned $learnedCount / ${ctx.size}", fontSize = 12.sp, color = Color(0xFF64748B))
            if (day.notes.isNotEmpty()) {
                TextButton(onClick = { notesOpen = !notesOpen }) { Text(if (notesOpen) "📌 Hide lesson notes" else "📌 Show lesson notes") }
                AnimatedVisibility(notesOpen) {
                    Soft(color = Color(0xFFEEF2FF)) {
                        day.notes.forEach { n ->
                            UrduText(n, Modifier.fillMaxWidth().padding(vertical = 2.dp), 17)
                        }
                    }
                }
            }
        }
        TabRow(selectedTabIndex = mode, containerColor = Color.White) {
            Tab(selected = mode == 0, onClick = { vm.sfx(S.CLICK); mode = 0 }, text = { Text("Cards") })
            Tab(selected = mode == 1, onClick = { vm.sfx(S.CLICK); mode = 1 }, text = { Text("Full list") })
        }
        if (mode == 0) {
            val cur = ctx[idx]
            val isLearned = vm.isLearned(d, cur.idx)
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Soft {
                    Text("${idx + 1} / ${ctx.size}", fontSize = 12.sp, color = Color(0xFF64748B))
                    if (cur.label.isNotEmpty()) {
                        UrduText(cur.label, Modifier.fillMaxWidth(), 14, color = Purple, bold = true)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        cur.s.en, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { vm.sfx(S.CLICK); vm.speak(cur.s.en) },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) { Text("🔊 Listen") }
                    Spacer(Modifier.height(8.dp))
                    AnimatedVisibility(showUr) {
                        UrduText(cur.s.ur, Modifier.fillMaxWidth(), 26, color = Purple, bold = true, align = TextAlign.Center)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { vm.sfx(S.CLICK); showUr = !showUr },
                        modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
                    ) { Text(if (showUr) "🙈 Hide Urdu" else "👁 Show Urdu", fontSize = 13.sp) }
                    Button(
                        onClick = { vm.sfx(S.CLICK); vm.toggleLearned(d, cur.idx) },
                        modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (isLearned) Green else Indigo)
                    ) { Text(if (isLearned) "✓ Learned" else "Mark as learned", fontSize = 13.sp) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { vm.sfx(S.CLICK); if (idx > 0) idx-- },
                        modifier = Modifier.weight(1f), enabled = idx > 0
                    ) { Text("← Prev") }
                    Button(
                        onClick = { vm.sfx(S.CLICK); if (idx < ctx.size - 1) idx++ },
                        modifier = Modifier.weight(1f), enabled = idx < ctx.size - 1
                    ) { Text("Next →") }
                }
            }
        } else {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(day.blocks) { b ->
                    when (b) {
                        is Block.Note -> Soft(color = Color(0xFFEEF2FF)) { UrduText(b.text, Modifier.fillMaxWidth(), 17) }
                        is Block.Title -> UrduText(b.text, Modifier.fillMaxWidth().padding(top = 8.dp), 18, color = Purple, bold = true)
                        is Block.Sent -> {
                            val sv = ctx.first { it.s === b }
                            val l = vm.isLearned(d, sv.idx)
                            Soft {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        if (b.tag.isNotEmpty()) Text(tagLabel(b.tag), fontSize = 12.sp, color = Purple, fontWeight = FontWeight.Bold)
                                        Text(b.en, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        if (showUr) UrduText(b.ur, Modifier.fillMaxWidth(), 18, color = Purple)
                                    }
                                    Text("🔊", fontSize = 24.sp, modifier = Modifier.clickable { vm.sfx(S.CLICK); vm.speak(b.en) }.padding(8.dp))
                                    Text(if (l) "✅" else "⬜", fontSize = 24.sp, modifier = Modifier.clickable { vm.sfx(S.CLICK); vm.toggleLearned(d, sv.idx) }.padding(8.dp))
                                }
                            }
                        }
                    }
                }
                item {
                    OutlinedButton(onClick = { vm.sfx(S.CLICK); showUr = !showUr }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (showUr) "🙈 Hide Urdu translations" else "👁 Show Urdu translations")
                    }
                }
            }
        }
        Column(Modifier.background(Color.White).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!allLearned && !lessonDone) {
                TextButton(onClick = { vm.sfx(S.CLICK); vm.learnAll(d) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Mark all as learned")
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { vm.sfx(S.CLICK); nav.navigate("revision/$d") },
                    modifier = Modifier.weight(1f)
                ) { Text("🔁 Revise") }
                Button(
                    onClick = {
                        val got = vm.finishLesson(d)
                        vm.sfx(S.COMPLETE)
                        if (got > 0) vm.sfx(S.COIN)
                        reward = got
                    },
                    modifier = Modifier.weight(1.4f),
                    enabled = allLearned && !lessonDone
                ) { Text(if (lessonDone) "Lesson done ✓" else "Finish (+10 🪙)") }
            }
            GradientButton(
                if (lessonDone) "🧠 Start Quiz" else "🔒 Finish lesson to unlock quiz",
                enabled = lessonDone
            ) { vm.sfx(S.CLICK); nav.navigate("quiz/$d") }
        }
    }
    if (reward >= 0) {
        AlertDialog(
            onDismissRequest = { reward = -1 },
            title = { Text("Lesson complete! 🎉") },
            text = { Text(if (reward > 0) "+$reward coins earned. Ready for the quiz?" else "Ready for the quiz?") },
            confirmButton = {
                TextButton(onClick = { reward = -1; nav.navigate("quiz/$d") }) { Text("Start Quiz") }
            },
            dismissButton = { TextButton(onClick = { reward = -1 }) { Text("Later") } }
        )
    }
}
