@file:OptIn(ExperimentalLayoutApi::class)

package com.learnenglish.urdu30

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Blue = Color(0xFF2563EB)
val Purple = Color(0xFF7C3AED)
val Indigo = Color(0xFF4F46E5)
val Bg = Color(0xFFF4F5FF)
val Ink = Color(0xFF1E1B4B)
val Green = Color(0xFF16A34A)
val Red = Color(0xFFDC2626)
val Gold = Color(0xFFF59E0B)
val Grad = Brush.linearGradient(listOf(Blue, Purple))

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Indigo, secondary = Purple, tertiary = Blue,
            background = Bg, surface = Color.White, onSurface = Ink, onBackground = Ink
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) { content() }
    }
}

@Composable
fun UrduText(
    t: String,
    modifier: Modifier = Modifier,
    size: Int = 20,
    color: Color = Ink,
    bold: Boolean = false,
    align: TextAlign = TextAlign.Start
) {
    Text(
        t, modifier = modifier, color = color, fontSize = size.sp,
        lineHeight = (size * 1.7f).sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        textAlign = align,
        style = TextStyle(textDirection = TextDirection.Rtl)
    )
}

@Composable
fun AppLogo(size: Dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Grad),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.offset(x = -(size * 0.09f), y = -(size * 0.1f))
                .size(size * 0.5f, size * 0.38f)
                .clip(RoundedCornerShape(size * 0.1f)).background(Color.White),
            contentAlignment = Alignment.Center
        ) { Text("A", color = Purple, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.26f).sp) }
        Box(
            Modifier.offset(x = size * 0.1f, y = size * 0.12f)
                .size(size * 0.46f, size * 0.36f)
                .clip(RoundedCornerShape(size * 0.1f)).background(Color(0xFFFFD54F)),
            contentAlignment = Alignment.Center
        ) { Text("ا", color = Purple, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.26f).sp) }
    }
}

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier.fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (enabled) Grad else SolidColor(Color(0xFFCBD5E1)))
            .clickable(enabled = enabled) { onClick() }
            .padding(vertical = 14.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center) }
}

@Composable
fun Soft(modifier: Modifier = Modifier, color: Color = Color.White, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = color),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) { Column(Modifier.padding(16.dp), content = content) }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().background(Grad).padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            Text(
                "←", color = Color.White, fontSize = 26.sp,
                modifier = Modifier.clickable { onBack() }.padding(horizontal = 12.dp, vertical = 2.dp)
            )
        } else Spacer(Modifier.width(12.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp, maxLines = 1)
    }
}

@Composable
fun WordChip(text: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(12.dp)).background(bg)
            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) { Text(text, color = fg, fontSize = 17.sp) }
}

@Composable
fun Stat(emoji: String, label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 24.sp)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Indigo)
            Text(label, fontSize = 12.sp, color = Color(0xFF64748B))
        }
    }
}

@Composable
fun LockedView(onBack: () -> Unit, msg: String = "This level is locked. Unlock it from the Levels screen.") {
    Column(Modifier.fillMaxSize()) {
        TopBar("Locked", onBack)
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🔒", fontSize = 56.sp)
            Spacer(Modifier.height(12.dp))
            Text(msg, textAlign = TextAlign.Center, fontSize = 16.sp)
            Spacer(Modifier.height(16.dp))
            GradientButton("Go Back") { onBack() }
        }
    }
}

fun tagLabel(tag: String): String = if (tag.length == 1) "Speaker $tag" else tag
