package com.learnenglish.urdu30

import android.app.Application
import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Locale

val Context.progressStore: DataStore<Preferences> by preferencesDataStore(name = "progress")

private val K_COINS = intPreferencesKey("coins")
private val K_UNL = stringPreferencesKey("unlocked")
private val K_LES = stringPreferencesKey("lessonDone")
private val K_COMP = stringPreferencesKey("completed")
private val K_BEST = stringPreferencesKey("best")
private val K_LEARN = stringPreferencesKey("learned")
private val K_REW = stringPreferencesKey("rewarded")
private val K_SND = booleanPreferencesKey("sound")

object S {
    const val CLICK = 0
    const val CORRECT = 1
    const val WRONG = 2
    const val COIN = 3
    const val UNLOCK = 4
    const val COMPLETE = 5
}

data class QuizResult(
    val day: Int,
    val score: Int,
    val total: Int,
    val answerCoins: Int,
    val bonusCoins: Int,
    val passed: Boolean
) {
    val stars: Int get() = when {
        score * 100 >= total * 90 -> 3
        score * 100 >= total * 75 -> 2
        score * 100 >= total * 60 -> 1
        else -> 0
    }
}

class AppVm(app: Application) : AndroidViewModel(app) {
    var loaded by mutableStateOf(false)
    var coins by mutableStateOf(0)
    var unlocked by mutableStateOf(setOf(1))
    var lessonDone by mutableStateOf(setOf<Int>())
    var completed by mutableStateOf(setOf<Int>())
    var best by mutableStateOf(mapOf<Int, Int>())
    var learned by mutableStateOf(setOf<String>())
    var rewarded by mutableStateOf(setOf<String>())
    var soundOn by mutableStateOf(true)
    var result by mutableStateOf<QuizResult?>(null)

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pool: SoundPool
    private val snd = IntArray(6)

    init {
        Curriculum.load(app)
        pool = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            ).build()
        snd[S.CLICK] = pool.load(app, R.raw.s_click, 1)
        snd[S.CORRECT] = pool.load(app, R.raw.s_correct, 1)
        snd[S.WRONG] = pool.load(app, R.raw.s_wrong, 1)
        snd[S.COIN] = pool.load(app, R.raw.s_coin, 1)
        snd[S.UNLOCK] = pool.load(app, R.raw.s_unlock, 1)
        snd[S.COMPLETE] = pool.load(app, R.raw.s_complete, 1)
        tts = TextToSpeech(app) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.setSpeechRate(0.9f)
                ttsReady = true
            }
        }
        viewModelScope.launch { load() }
    }

    private fun ints(s: String?): Set<Int> = (s ?: "").split(",").mapNotNull { it.toIntOrNull() }.toSet()
    private fun strs(s: String?): Set<String> = (s ?: "").split(",").filter { it.isNotEmpty() }.toSet()

    private suspend fun load() {
        val p = getApplication<Application>().progressStore.data.first()
        coins = maxOf(0, p[K_COINS] ?: 0)
        unlocked = ints(p[K_UNL]) + 1
        lessonDone = ints(p[K_LES])
        completed = ints(p[K_COMP])
        best = (p[K_BEST] ?: "").split(",").filter { it.contains(":") }.associate {
            val a = it.split(":")
            a[0].toInt() to a[1].toInt()
        }
        learned = strs(p[K_LEARN])
        rewarded = strs(p[K_REW])
        soundOn = p[K_SND] ?: true
        loaded = true
    }

    private fun save() {
        if (!loaded) return
        viewModelScope.launch {
            getApplication<Application>().progressStore.edit { p ->
                p[K_COINS] = coins
                p[K_UNL] = unlocked.joinToString(",")
                p[K_LES] = lessonDone.joinToString(",")
                p[K_COMP] = completed.joinToString(",")
                p[K_BEST] = best.entries.joinToString(",") { "${it.key}:${it.value}" }
                p[K_LEARN] = learned.joinToString(",")
                p[K_REW] = rewarded.joinToString(",")
                p[K_SND] = soundOn
            }
        }
    }

    // ---------- sound & speech ----------
    fun sfx(i: Int) {
        if (soundOn) pool.play(snd[i], 1f, 1f, 1, 0, 1f)
    }

    fun speak(t: String) {
        if (ttsReady) tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    fun setSound(on: Boolean) {
        soundOn = on
        save()
    }

    // ---------- derived ----------
    val currentDay: Int get() = (1..30).firstOrNull { it !in completed } ?: 30

    val earnedTotal: Int get() = rewarded.fold(0) { a, k ->
        a + when {
            k.startsWith("q:") -> 2
            k.startsWith("lesson:") -> 10
            k.startsWith("quiz:") -> 10
            k.startsWith("week:") -> 15
            k == "final" -> 50
            else -> 0
        }
    }

    companion object {
        fun priceOf(d: Int): Int = when (d) {
            1 -> 0
            2 -> 30
            3 -> 40
            4 -> 50
            else -> 50 + (d - 4) / 3
        }
    }

    // ---------- coins ----------
    private fun reward(n: Int, key: String): Boolean {
        if (n <= 0 || key in rewarded) return false
        rewarded = rewarded + key
        coins += n
        save()
        return true
    }

    private fun spend(n: Int): Boolean {
        if (n < 0 || coins < n) return false
        coins -= n
        if (coins < 0) coins = 0
        save()
        return true
    }

    fun canUnlock(d: Int): Boolean =
        d in 2..30 && d !in unlocked && (d - 1) in unlocked && coins >= priceOf(d)

    fun unlock(d: Int): Boolean {
        if (d !in 2..30 || d in unlocked || (d - 1) !in unlocked) return false
        if (!spend(priceOf(d))) return false
        unlocked = unlocked + d
        save()
        return true
    }

    // ---------- lessons ----------
    fun isLearned(d: Int, i: Int) = "$d:$i" in learned

    fun toggleLearned(d: Int, i: Int) {
        val k = "$d:$i"
        learned = if (k in learned) learned - k else learned + k
        save()
    }

    fun learnAll(d: Int) {
        val n = Curriculum.days[d - 1].sents.size
        learned = learned + (0 until n).map { "$d:$it" }
        save()
    }

    fun learnedCount(d: Int): Int = (0 until Curriculum.days[d - 1].sents.size).count { "$d:$it" in learned }

    /** returns coins awarded (0 if already rewarded) */
    fun finishLesson(d: Int): Int {
        lessonDone = lessonDone + d
        val got = if (reward(10, "lesson:$d")) 10 else 0
        save()
        return got
    }

    // ---------- quiz ----------
    fun rewardAnswer(d: Int, qi: Int): Int = if (reward(2, "q:$d:$qi")) 2 else 0

    fun finishQuiz(d: Int, score: Int, total: Int, answerCoins: Int): QuizResult {
        best = best + (d to maxOf(best[d] ?: 0, score))
        val passed = score * 100 >= total * 60
        var bonus = 0
        if (passed) {
            if (reward(10, "quiz:$d")) bonus += 10
            if ((d == 7 || d == 14 || d == 21) && reward(15, "week:$d")) bonus += 15
            if (d == 30 && reward(50, "final")) bonus += 50
            completed = completed + d
        }
        save()
        val r = QuizResult(d, score, total, answerCoins, bonus, passed)
        result = r
        return r
    }

    fun resetAll() {
        coins = 0
        unlocked = setOf(1)
        lessonDone = emptySet()
        completed = emptySet()
        best = emptyMap()
        learned = emptySet()
        rewarded = emptySet()
        result = null
        save()
    }

    override fun onCleared() {
        tts?.shutdown()
        pool.release()
        super.onCleared()
    }
}
