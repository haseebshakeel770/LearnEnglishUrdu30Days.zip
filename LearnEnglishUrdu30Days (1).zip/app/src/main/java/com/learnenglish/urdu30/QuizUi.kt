@file:OptIn(ExperimentalLayoutApi::class)

package com.learnenglish.urdu30

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

private fun typeLabel(t: QT): String = when (t) {
    QT.MCQ -> "Multiple Choice"
    QT.E2U -> "English → Urdu (arrange the Urdu words)"
    QT.U2E -> "Urdu → English"
    QT.MISSING -> "Missing Word"
    QT.ARRANGE -> "Word Arrangement"
    QT.MATCH -> "Matching"
    QT.TF -> "True / False"
}

@Composable
fun QuizScreen(vm: AppVm, d: Int, nav: NavController) {
    if (d !in vm.unlocked || d !in vm.lessonDone) {
        LockedView({ nav.popBackStack() }, "Finish the lesson first to unlock this quiz.")
    } else QuizContent(vm, d, nav)
}

@Composable
fun QuizContent(vm: AppVm, d: Int, nav: NavController) {
    val qs = remember(d) { QuizGen.build(d) }
    var qi by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var earned by remember { mutableStateOf(0) }
    var verdict by remember(qi) { mutableStateOf<Boolean?>(null) }
    var gained by remember(qi) { mutableStateOf(0) }
    val q = qs[qi]

    fun submit(ok: Boolean) {
        if (verdict != null) return
        verdict = ok
        if (ok) {
            score++
            val c = vm.rewardAnswer(d, qi)
            gained = c
            earned += c
            vm.sfx(S.CORRECT)
            if (c > 0) vm.sfx(S.COIN)
        } else {
            vm.sfx(S.WRONG)
        }
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar("Day $d Quiz", { nav.popBackStack() })
        LinearProgressIndicator(
            progress = (qi + (if (verdict != null) 1 else 0)) / qs.size.toFloat(),
            modifier = Modifier.fillMaxWidth().height(6.dp),
            color = Gold, trackColor = Color(0xFFE0E7FF)
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text("Question ${qi + 1}/${qs.size}", Modifier.weight(1f), color = Color(0xFF64748B))
            Text("🪙 +$earned  •  ✅ $score", fontWeight = FontWeight.Bold, color = Indigo)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(typeLabel(q.type), color = Purple, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            key(qi) {
                when (q.type) {
                    QT.MCQ -> {
                        PromptCard { Text(q.prompt, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
                        SpeakRow(vm, q.prompt)
                        OptionList(q.options, q.answer, verdict != null, true) { submit(it == q.answer) }
                    }
                    QT.U2E -> {
                        PromptCard { UrduText(q.prompt, Modifier.fillMaxWidth(), 24, bold = true, align = TextAlign.Center) }
                        OptionList(q.options, q.answer, verdict != null, false) { submit(it == q.answer) }
                    }
                    QT.MISSING -> {
                        PromptCard {
                            Text(q.prompt, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(6.dp))
                            UrduText(q.sub, Modifier.fillMaxWidth(), 20, color = Purple, align = TextAlign.Center)
                        }
                        OptionList(q.options, q.answer, verdict != null, false) { submit(it == q.answer) }
                    }
                    QT.TF -> {
                        PromptCard {
                            Text(q.prompt, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(6.dp))
                            UrduText(q.sub, Modifier.fillMaxWidth(), 22, color = Purple, align = TextAlign.Center)
                            Spacer(Modifier.height(4.dp))
                            Text("Is this translation correct?", fontSize = 13.sp, color = Color(0xFF64748B), modifier = Modifier.align(Alignment.CenterHorizontally))
                        }
                        val ans = if (q.tfTrue) "True" else "False"
                        OptionList(q.options, ans, verdict != null, false) { submit(it == ans) }
                    }
                    QT.E2U -> {
                        PromptCard { Text(q.prompt, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
                        ArrangeBody(q, verdict != null, true) { submit(it) }
                    }
                    QT.ARRANGE -> {
                        PromptCard { UrduText(q.prompt, Modifier.fillMaxWidth(), 24, bold = true, align = TextAlign.Center) }
                        ArrangeBody(q, verdict != null, false) { submit(it) }
                    }
                    QT.MATCH -> {
                        Text(q.prompt, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        MatchBody(vm, q, verdict != null) { submit(it) }
                    }
                }
            }
            val v = verdict
            if (v != null) {
                Soft(color = if (v) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)) {
                    Text(
                        if (v) "✅ Correct!" + (if (gained > 0) "  +$gained coins" else "") else "❌ Incorrect",
                        fontWeight = FontWeight.Bold, fontSize = 18.sp, color = if (v) Green else Red
                    )
                    if (!v) {
                        Spacer(Modifier.height(6.dp))
                        Text("Correct answer:", fontSize = 13.sp, color = Color(0xFF64748B))
                        AnswerView(q)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        if (verdict != null) {
            Box(Modifier.background(Color.White).padding(12.dp)) {
                GradientButton(if (qi == qs.size - 1) "See Results" else "Next →") {
                    vm.sfx(S.CLICK)
                    if (qi == qs.size - 1) {
                        vm.finishQuiz(d, score, qs.size, earned)
                        nav.navigate("results") { popUpTo("quiz/{d}") { inclusive = true } }
                    } else qi++
                }
            }
        }
    }
}

@Composable
fun PromptCard(content: @Composable ColumnScope.() -> Unit) {
    Soft(color = Color.White, content = content)
}

@Composable
fun SpeakRow(vm: AppVm, text: String) {
    OutlinedButton(onClick = { vm.sfx(S.CLICK); vm.speak(text) }) { Text("🔊 Listen") }
}

@Composable
fun AnswerView(q: Question) {
    when (q.type) {
        QT.MCQ, QT.E2U -> UrduText(q.answer, Modifier.fillMaxWidth(), 20, bold = true)
        QT.U2E, QT.ARRANGE -> Text(q.answer, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        QT.MISSING -> Text(q.full, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        QT.TF -> {
            Text(q.prompt, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            UrduText(q.answer, Modifier.fillMaxWidth(), 20)
        }
        QT.MATCH -> q.pairsEn.indices.forEach { i ->
            Text(q.pairsEn[i], fontWeight = FontWeight.Bold)
            UrduText(q.pairsUr[i], Modifier.fillMaxWidth().padding(bottom = 6.dp), 18)
        }
    }
}

@Composable
fun OptionList(opts: List<String>, answer: String, done: Boolean, urdu: Boolean, onPick: (String) -> Unit) {
    var picked by remember { mutableStateOf<String?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        opts.forEach { o ->
            val isAns = o == answer
            val isPick = o == picked
            val bg = when {
                done && isAns -> Color(0xFFDCFCE7)
                done && isPick -> Color(0xFFFEE2E2)
                else -> Color.White
            }
            val bd = when {
                done && isAns -> Green
                done && isPick -> Red
                isPick -> Purple
                else -> Color(0xFFE2E8F0)
            }
            Box(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(bg)
                    .border(2.dp, bd, RoundedCornerShape(16.dp))
                    .clickable(enabled = !done) { picked = o; onPick(o) }
                    .padding(16.dp)
            ) {
                if (urdu) UrduText(o, Modifier.fillMaxWidth(), 20)
                else Text(o, fontSize = 18.sp, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
fun ArrangeBody(q: Question, done: Boolean, rtl: Boolean, onCheck: (Boolean) -> Unit) {
    var chosen by remember { mutableStateOf(listOf<Int>()) }
    val dir = if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides dir) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.fillMaxWidth().heightIn(min = 80.dp)
                    .clip(RoundedCornerShape(16.dp)).background(Color(0xFFEEF2FF)).padding(10.dp)
            ) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    chosen.forEach { i ->
                        WordChip(q.tokens[i], Purple, Color.White) { if (!done) chosen = chosen - i }
                    }
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                q.tokens.indices.forEach { i ->
                    if (i !in chosen) {
                        WordChip(q.tokens[i], Color.White, Ink) { if (!done) chosen = chosen + i }
                    }
                }
            }
            if (!done) {
                GradientButton("Check", enabled = chosen.size == q.tokens.size) {
                    onCheck(chosen.joinToString(" ") { q.tokens[it] } == q.answer)
                }
            }
        }
    }
}

@Composable
fun MatchBody(vm: AppVm, q: Question, done: Boolean, onDone: (Boolean) -> Unit) {
    val n = q.pairsEn.size
    val orderEn = remember { (0 until n).shuffled() }
    val orderUr = remember { (0 until n).shuffled() }
    var sel by remember { mutableStateOf<Int?>(null) }
    var matched by remember { mutableStateOf(setOf<Int>()) }
    var mistakes by remember { mutableStateOf(0) }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            orderEn.forEach { i ->
                val m = i in matched
                MatchCell(q.pairsEn[i], m, sel == i, false) {
                    if (!m && !done) { vm.sfx(S.CLICK); sel = i }
                }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            orderUr.forEach { i ->
                val m = i in matched
                MatchCell(q.pairsUr[i], m, false, true) {
                    val s = sel
                    if (s != null && !m && !done) {
                        if (s == i) {
                            matched = matched + i
                            vm.sfx(S.CORRECT)
                            if (matched.size == n) onDone(mistakes == 0)
                        } else {
                            mistakes++
                            vm.sfx(S.WRONG)
                        }
                        sel = null
                    }
                }
            }
        }
    }
}

@Composable
fun MatchCell(text: String, matched: Boolean, selected: Boolean, urdu: Boolean, onClick: () -> Unit) {
    val bg = when {
        matched -> Color(0xFFDCFCE7)
        selected -> Color(0xFFEDE9FE)
        else -> Color.White
    }
    val bd = when {
        matched -> Green
        selected -> Purple
        else -> Color(0xFFE2E8F0)
    }
    Box(
        Modifier.fillMaxWidth().heightIn(min = 64.dp)
            .clip(RoundedCornerShape(14.dp)).background(bg)
            .border(2.dp, bd, RoundedCornerShape(14.dp))
            .clickable { onClick() }.padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        if (urdu) UrduText(text, Modifier.fillMaxWidth(), 16, align = TextAlign.Center)
        else Text(text, fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun ResultsScreen(vm: AppVm, nav: NavController) {
    val r = vm.result
    if (r == null) {
        LaunchedEffect(Unit) { nav.popBackStack() }
        return
    }
    LaunchedEffect(r) {
        if (r.passed) { vm.sfx(S.COMPLETE) } else vm.sfx(S.WRONG)
        if (r.answerCoins + r.bonusCoins > 0) vm.sfx(S.COIN)
    }
    Column(
        Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text(if (r.passed) "🎉 Well done!" else "💪 Keep practicing", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Indigo)
        Text("Day ${r.day} Quiz", color = Color(0xFF64748B))
        Text("⭐".repeat(r.stars) + "☆".repeat(3 - r.stars), fontSize = 36.sp)
        Soft {
            Text("Score: ${r.score} / ${r.total}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("🪙 Answer coins: +${r.answerCoins}")
            Text("🎁 Bonus coins: +${r.bonusCoins}")
            Text("💰 Wallet: ${vm.coins}")
            Spacer(Modifier.height(6.dp))
            Text(
                if (r.passed) "You passed! Day ${r.day} is completed." else "You need 60% to complete the day. Try again!",
                color = if (r.passed) Green else Red, fontWeight = FontWeight.Bold
            )
            if (r.day in listOf(7, 14, 21) && r.passed) Text("Weekly revision bonus: +15 (first time only)", fontSize = 12.sp, color = Color(0xFF64748B))
        }
        if (r.passed && r.day == 30) {
            GradientButton("🏆 Finish the Challenge") {
                nav.navigate("final") { popUpTo("home") { inclusive = false } }
            }
        } else if (r.passed && r.day < 30) {
            GradientButton(if ((r.day + 1) in vm.unlocked) "Next: Day ${r.day + 1} ▶" else "🔓 Unlock Day ${r.day + 1} (${AppVm.priceOf(r.day + 1)} 🪙)") {
                vm.sfx(S.CLICK)
                if ((r.day + 1) in vm.unlocked) nav.navigate("lesson/${r.day + 1}") { popUpTo("home") { inclusive = false } }
                else nav.navigate("levels") { popUpTo("home") { inclusive = false } }
            }
        }
        OutlinedButton(
            onClick = { vm.sfx(S.CLICK); nav.navigate("quiz/${r.day}") { popUpTo("results") { inclusive = true } } },
            modifier = Modifier.fillMaxWidth()
        ) { Text("🔄 Retry Quiz") }
        TextButton(onClick = { vm.sfx(S.CLICK); nav.navigate("levels") { popUpTo("home") { inclusive = false } } }) { Text("Back to Levels") }
    }
}
