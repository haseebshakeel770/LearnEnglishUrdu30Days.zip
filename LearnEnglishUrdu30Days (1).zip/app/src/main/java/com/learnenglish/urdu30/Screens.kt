@file:OptIn(ExperimentalLayoutApi::class)

package com.learnenglish.urdu30

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.delay

// ---------------------------------------------------------------- Splash
@Composable
fun SplashScreen(vm: AppVm, nav: NavController) {
    var go by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (go) 1f else 0.4f, tween(900), label = "logo")
    LaunchedEffect(Unit) {
        go = true
        delay(1800)
        while (!vm.loaded) delay(50)
        nav.navigate("home") { popUpTo("splash") { inclusive = true } }
    }
    Column(
        Modifier.fillMaxSize().background(Grad),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.scale(sc)) { AppLogo(140.dp) }
        Spacer(Modifier.height(24.dp))
        Text(
            "Learn English in Urdu", color = Color.White, fontSize = 28.sp,
            fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
        )
        Text("30 Days", color = Color(0xFFFFD54F), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        UrduText("اردو کے ساتھ انگلش سیکھیں", color = Color.White, size = 20, align = TextAlign.Center)
        Spacer(Modifier.height(32.dp))
        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
    }
}

// ---------------------------------------------------------------- Home
@Composable
fun HomeScreen(vm: AppVm, nav: NavController) {
    val cur = vm.currentDay
    val done = vm.completed.size
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState())) {
        Box(
            Modifier.fillMaxWidth()
                .background(Grad, RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                .padding(24.dp)
        ) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                AppLogo(84.dp)
                Spacer(Modifier.height(10.dp))
                Text(
                    "Learn English in Urdu – 30 Days", color = Color.White, fontSize = 22.sp,
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(6.dp))
                Text("Welcome back! 👋", color = Color.White, fontSize = 16.sp)
                UrduText("خوش آمدید! آج کچھ نیا سیکھیں", color = Color.White, size = 17, align = TextAlign.Center)
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("🪙", "Coins", "${vm.coins}", Modifier.weight(1f))
                Stat("✅", "Completed", "$done/30", Modifier.weight(1f))
                Stat("📅", "Current Day", "$cur", Modifier.weight(1f))
            }
            Soft {
                Text("Learning Progress", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = done / 30f,
                    modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(8.dp)),
                    color = Purple, trackColor = Color(0xFFE0E7FF)
                )
                Spacer(Modifier.height(6.dp))
                Text("${done * 100 / 30}% complete • ${vm.learned.size}/${Curriculum.totalSentences} sentences learned", fontSize = 13.sp, color = Color(0xFF64748B))
            }
            val d = Curriculum.days[cur - 1]
            Soft {
                Text("Day $cur", color = Purple, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                UrduText(d.title, Modifier.fillMaxWidth(), 22, bold = true)
            }
            if (cur in vm.unlocked) {
                GradientButton("▶  Continue Learning") { vm.sfx(S.CLICK); nav.navigate("lesson/$cur") }
            } else {
                GradientButton("🔒  Unlock Day $cur (${AppVm.priceOf(cur)} 🪙)") { vm.sfx(S.CLICK); nav.navigate("levels") }
            }
            OutlinedButton(
                onClick = { vm.sfx(S.CLICK); nav.navigate("guide") },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)
            ) { Text("📘 30 Days Challenge Guide") }
            if (done >= 30) {
                OutlinedButton(
                    onClick = { vm.sfx(S.CLICK); nav.navigate("final") },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)
                ) { Text("🏆 View Final Completion Screen") }
            }
        }
    }
}

// ---------------------------------------------------------------- Guide
@Composable
fun GuideScreen(nav: NavController) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar("30 Days Challenge", { nav.popBackStack() })
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Curriculum.guide.forEach { (kind, text) ->
                when (kind) {
                    "T" -> Text(text, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Indigo)
                    "H" -> UrduText(text, Modifier.fillMaxWidth(), 20, bold = true, color = Purple)
                    else -> Soft { UrduText("•  $text", Modifier.fillMaxWidth(), 18) }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Levels
@Composable
fun LevelsScreen(vm: AppVm, nav: NavController) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar("Levels – Day 1 to Day 30", null)
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items((1..30).toList()) { d -> LevelCard(vm, nav, d) }
        }
    }
}

@Composable
fun LevelCard(vm: AppVm, nav: NavController, d: Int) {
    val day = Curriculum.days[d - 1]
    val open = d in vm.unlocked
    val finished = d in vm.completed
    Soft(color = if (open) Color.White else Color(0xFFF1F5F9)) {
        if (day.week.isNotEmpty()) {
            UrduText(day.week, Modifier.fillMaxWidth(), 14, color = Purple, bold = true)
            Spacer(Modifier.height(6.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(CircleShape)
                    .background(if (finished) SolidGreen else if (open) Grad else SolidGray),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (finished) "✓" else if (open) "$d" else "🔒",
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Day $d", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                UrduText(day.title, Modifier.fillMaxWidth(), 16)
                val b = vm.best[d]
                Text(
                    when {
                        finished -> "Completed • best ${b ?: 0}/${QuizGen.COUNT}"
                        open -> "Unlocked • ${vm.learnedCount(d)}/${day.sents.size} learned"
                        else -> "Price: ${AppVm.priceOf(d)} 🪙"
                    },
                    fontSize = 12.sp, color = Color(0xFF64748B)
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        if (open) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { vm.sfx(S.CLICK); nav.navigate("lesson/$d") },
                    Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
                ) { Text("📖 Lesson", fontSize = 13.sp) }
                Button(
                    onClick = { vm.sfx(S.CLICK); nav.navigate("quiz/$d") },
                    Modifier.weight(1f), enabled = d in vm.lessonDone,
                    contentPadding = PaddingValues(4.dp)
                ) { Text("🧠 Quiz", fontSize = 13.sp) }
                OutlinedButton(
                    onClick = { vm.sfx(S.CLICK); nav.navigate("revision/$d") },
                    Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
                ) { Text("🔁 Revise", fontSize = 13.sp) }
            }
        } else {
            val prevOpen = (d - 1) in vm.unlocked
            val price = AppVm.priceOf(d)
            val enough = vm.coins >= price
            Button(
                onClick = { if (vm.unlock(d)) vm.sfx(S.UNLOCK) },
                modifier = Modifier.fillMaxWidth(),
                enabled = prevOpen && enough
            ) {
                Text(
                    when {
                        !prevOpen -> "Unlock Day ${d - 1} first"
                        !enough -> "Need ${price - vm.coins} more coins"
                        else -> "🔓 Unlock for $price 🪙"
                    }
                )
            }
        }
    }
}

val SolidGreen = androidx.compose.ui.graphics.SolidColor(Green)
val SolidGray = androidx.compose.ui.graphics.SolidColor(Color(0xFF94A3B8))

// ---------------------------------------------------------------- Wallet
@Composable
fun WalletScreen(vm: AppVm) {
    val nextLocked = (1..30).firstOrNull { it !in vm.unlocked }
    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar("Coins Wallet", null)
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Grad).padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🪙", fontSize = 44.sp)
                    Text("${vm.coins}", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Bold)
                    Text("coins available", color = Color.White)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("📈", "Earned", "${vm.earnedTotal}", Modifier.weight(1f))
                Stat("🔓", "Spent", "${(vm.earnedTotal - vm.coins).coerceAtLeast(0)}", Modifier.weight(1f))
            }
            if (nextLocked != null) {
                val price = AppVm.priceOf(nextLocked)
                Soft {
                    Text("Next unlock: Day $nextLocked", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = (vm.coins.toFloat() / price).coerceIn(0f, 1f),
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(8.dp)),
                        color = Gold, trackColor = Color(0xFFFEF3C7)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("${vm.coins} / $price coins", fontSize = 13.sp, color = Color(0xFF64748B))
                }
            }
            Soft {
                Text("How to earn coins", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                listOf(
                    "✅ Each correct answer (once per question)" to "+2",
                    "📖 Finish a lesson" to "+10",
                    "🧠 Pass the daily quiz (60%+)" to "+10",
                    "🔁 Weekly revision quiz (Day 7, 14, 21)" to "+15",
                    "🏆 Finish Day 30" to "+50"
                ).forEach { (a, b) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Text(a, Modifier.weight(1f), fontSize = 14.sp)
                        Text(b, fontWeight = FontWeight.Bold, color = Green)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Rewards are given only once, so replaying never duplicates coins. Missed questions can still be earned when answered correctly later.",
                    fontSize = 12.sp, color = Color(0xFF64748B)
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Progress
@Composable
fun ProgressScreen(vm: AppVm, nav: NavController) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar("My Progress", null)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Soft {
                    val done = vm.completed.size
                    Text("Overall: $done / 30 days", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = done / 30f,
                        modifier = Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(8.dp)),
                        color = Purple, trackColor = Color(0xFFE0E7FF)
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("📖 Lessons finished: ${vm.lessonDone.size}/30")
                    Text("🧠 Quizzes passed: ${vm.completed.size}/30")
                    Text("🗣 Sentences learned: ${vm.learned.size}/${Curriculum.totalSentences}")
                    Text("🔓 Levels unlocked: ${vm.unlocked.size}/30")
                    val avg = if (vm.best.isEmpty()) 0 else vm.best.values.sum() * 100 / (vm.best.size * QuizGen.COUNT)
                    Text("⭐ Average best quiz score: $avg%")
                }
            }
            items((1..30).toList()) { d ->
                val open = d in vm.unlocked
                Soft {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Day $d", fontWeight = FontWeight.Bold)
                            Text(
                                when {
                                    d in vm.completed -> "✅ Completed • best ${vm.best[d] ?: 0}/${QuizGen.COUNT}"
                                    !open -> "🔒 Locked"
                                    d in vm.lessonDone -> "📖 Lesson done • quiz pending (best ${vm.best[d] ?: 0}/${QuizGen.COUNT})"
                                    else -> "▶ In progress • ${vm.learnedCount(d)}/${Curriculum.days[d - 1].sents.size} learned"
                                },
                                fontSize = 12.sp, color = Color(0xFF64748B)
                            )
                        }
                        if (open) {
                            TextButton(onClick = { vm.sfx(S.CLICK); nav.navigate("revision/$d") }) { Text("🔁 Revise") }
                        }
                    }
                }
            }
            if (vm.completed.size >= 30) {
                item { GradientButton("🏆 Final Completion Screen") { nav.navigate("final") } }
            }
        }
    }
}

// ---------------------------------------------------------------- Settings
@Composable
fun SettingsScreen(vm: AppVm, nav: NavController) {
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar("Settings", null)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Soft {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("🔊 Sound effects", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Short click, reward and result sounds. No background music.", fontSize = 12.sp, color = Color(0xFF64748B))
                    }
                    Switch(checked = vm.soundOn, onCheckedChange = { vm.setSound(it) })
                }
            }
            Soft {
                Text("📘 Study guide", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { nav.navigate("guide") }, modifier = Modifier.fillMaxWidth()) { Text("Open 30 Days Challenge guide") }
            }
            Soft {
                Text("🗑 Reset progress", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Deletes coins, unlocked levels, scores and learned sentences.", fontSize = 12.sp, color = Color(0xFF64748B))
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { confirm = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Red),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Reset everything") }
            }
            Soft {
                Text("About", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Learn English in Urdu – 30 Days • v1.0", fontSize = 13.sp)
                Text("Works fully offline. Pronunciation uses your phone's built-in text-to-speech (install an English voice in Android settings if you hear nothing).", fontSize = 12.sp, color = Color(0xFF64748B))
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Reset all progress?") },
            text = { Text("This cannot be undone.") },
            confirmButton = { TextButton(onClick = { vm.resetAll(); confirm = false }) { Text("Reset", color = Red) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- Final
@Composable
fun FinalScreen(vm: AppVm, nav: NavController) {
    Column(
        Modifier.fillMaxSize().background(Grad).verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🎉🏆🎓", fontSize = 56.sp)
        Spacer(Modifier.height(12.dp))
        Text("Congratulations!", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("You finished the 30 Days Challenge", color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center)
        UrduText("مبارک ہو! آپ نے 30 دن مکمل کر لیے", color = Color(0xFFFFD54F), size = 22, bold = true, align = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Soft {
            Text("🪙 Coins: ${vm.coins}")
            Text("✅ Days completed: ${vm.completed.size}/30")
            Text("🗣 Sentences learned: ${vm.learned.size}/${Curriculum.totalSentences}")
            val avg = if (vm.best.isEmpty()) 0 else vm.best.values.sum() * 100 / (vm.best.size * QuizGen.COUNT)
            Text("⭐ Average best score: $avg%")
        }
        Spacer(Modifier.height(10.dp))
        Text("I will speak English with confidence.", color = Color.White, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        UrduText("میں اعتماد کے ساتھ انگلش بولوں گا۔", color = Color.White, size = 18, align = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { nav.navigate("home") { popUpTo("home") { inclusive = false }; launchSingleTop = true } },
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Indigo),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Back to Home") }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = { nav.navigate("progress") { popUpTo("home") { inclusive = false }; launchSingleTop = true } }) {
            Text("View my progress", color = Color.White)
        }
    }
}

// ---------------------------------------------------------------- Revision flashcards
@Composable
fun RevisionScreen(vm: AppVm, d: Int, nav: NavController) {
    if (d !in vm.unlocked) { LockedView({ nav.popBackStack() }); return }
    val list = remember(d) { Curriculum.revisionSentences(d) }
    var i by remember { mutableStateOf(0) }
    var shown by remember { mutableStateOf(false) }
    val s = list[i]
    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar("Revision – Day $d", { nav.popBackStack() })
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Card ${i + 1} of ${list.size}", color = Color(0xFF64748B))
            LinearProgressIndicator(
                progress = (i + 1) / list.size.toFloat(),
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)),
                color = Purple, trackColor = Color(0xFFE0E7FF)
            )
            Soft {
                Text("Say it in English:", fontSize = 13.sp, color = Color(0xFF64748B))
                UrduText(s.ur, Modifier.fillMaxWidth().padding(vertical = 12.dp), 26, bold = true, align = TextAlign.Center)
                if (shown) {
                    Text(
                        s.en, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Purple,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { vm.sfx(S.CLICK); vm.speak(s.en) }, modifier = Modifier.fillMaxWidth()) { Text("🔊 Listen") }
                }
            }
            GradientButton(if (shown) "Hide answer" else "Show answer") { vm.sfx(S.CLICK); shown = !shown }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { vm.sfx(S.CLICK); i = (i - 1 + list.size) % list.size; shown = false },
                    modifier = Modifier.weight(1f)
                ) { Text("← Previous") }
                Button(
                    onClick = { vm.sfx(S.CLICK); i = (i + 1) % list.size; shown = false },
                    modifier = Modifier.weight(1f)
                ) { Text("Next →") }
            }
        }
    }
}
