# Learn English in Urdu – 30 Days
Kotlin + Jetpack Compose + Material 3 • minSdk 24 • compileSdk 34 • offline.

Build: push to GitHub → Actions → "Build Debug APK" → download artifact `LearnEnglishUrdu30Days-debug-apk`.
Local: open in Android Studio (Hedgehog or newer, JDK 17) and run, or `gradle assembleDebug`.

Curriculum lives in `app/src/main/assets/curriculum.txt` (all 30 days, original text).
Unlock prices: `AppVm.priceOf()` in `Store.kt`. Quiz generator: `QuizGen` in `Data.kt`.
